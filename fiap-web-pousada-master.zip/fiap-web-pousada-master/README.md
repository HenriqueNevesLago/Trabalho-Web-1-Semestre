# Site de uma pousada

- Projeto desenvolvido na disciplina de Responsive Web Development;
- O mesmo possui como proposta a criação de um site para uma pousada, contendo informações iniciais, de serviços, contato e etc;
- Foi desenvolvido no mesmo um remake de um site de um hotel já existente;
- [Site original do hotel](https://www.hyatt.com/pt-PT/home/).
